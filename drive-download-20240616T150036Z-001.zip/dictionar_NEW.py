def one():
    tabelNote = {}
    tabelStud = {}
    n = int(input("Numar de studenti: "))
    print("Programul citeste informatiile despre un student intr-o inregistrare text formata din 3 campuri separate cu o virgula, primul cmp fiind ID-ul.")
    for i in range(n):
        student = input(f"Student {i+1}: ").split(',')
        id = int(student[0])
        nume_stud = student[1].strip()
        note_stud = [int(nota) for nota in student[2].split()]
        tabelNote[id] = note_stud
        tabelStud[id] = nume_stud
    return tabelStud, tabelNote

def afisare(D):
    for k in D:
        print(k, D[k], sep='\t')

def four(Student,Note):
    for i in Student:
        print(i, Student[i], Note[i])


def five(Student,Note):
    nume = input("Introduceti numele studentului/studentei: ")
    found = 0
    for id in Student:
        if Student[id] == nume:
            found = 1
            print(id, Student[id], Note[id])
    if found == 0:
        print("No student found")

def six(Studenti,Note):
    for id in Studenti:
        neprom = 0
        for nota in Note[id]:
            if nota<5:
                neprom = 1
        if neprom == 0:
            print(id,Studenti[id],Note[id])


def menu():
    tabelStud = {}
    tabelNote = {}
    menu = {
        1: "Incarcare informatii despre studenti de la tastatura",
        2: "Afisare studenti",
        3: "Afisare note",
        4: "Afisare studenti si notele obtinute",
        5: "Cautare student dupa nume",
        6: "Afisare studenti promovati",
        7: "Info autor",
        8: "Termina program"
    }

    while True:
        for k in menu:
            print(k, menu[k], sep='.')
        option = int(input("Introduceti optiunea: "))

        match option:
            case 1:
                tabelStud, tabelNote = one()
            case 2:
                afisare(tabelStud)
            case 3:
                afisare(tabelNote)
            case 4:
                four(tabelStud,tabelNote)
            case 5:
                five(tabelStud,tabelNote)
            case 6:
                six(tabelStud,tabelNote)
            case 7:
                print("Anon")
            case 8:
                return

menu()
