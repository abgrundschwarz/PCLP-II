def one():
    global mat,m,n
    mat = []
    n = int(input("Linii: "))
    m = int(input("Coloane: "))

    for i in range(n):
        mat.append(input(f"Linia {i}: ").split())
    return n,m,mat

def three():
    linmax = []
    for i in mat:
        linmax.append(max(i))
    print(linmax)

def four():
    colmax = []
    temp = []
    for i in range(m):
        for j in range(n):
            temp.append(mat[j][i])
        colmax.append(max(temp))
        temp = []
    print(colmax)

def five():
    mat_t = [[0 for i in range(n)] for j in range(m)]
    for i in range(m):
        for j in range(n):
            mat_t[i][j]=mat[j][i]
    print(mat_t)

def six():
    global n
    mat.append(input(f"Linia {n}: ").split())
    n += 1

def seven():
    counter = 0
    global m
    for i in mat:
        i.append(int(input(f"Coloana {m}, el [{counter}]: ")))
        counter += 1
    m += 1

def eight():
    y = int(input("Linia pe care vreti sa o eliminati: "))
    mat.pop(y)
def nine():
    x = int(input("Coloana pe care vreti sa o eliminati: "))

    for i in mat:
        i.pop(x)

def ten():
    mat_list = []
    for i in mat:
        for j in i:
            mat_list.append(j)
    print(mat_list)

def menu():
    while 1:
        print("1. Citire matrice de la tastatura (pe linii)\n2. Afisare matrice\n3. Creare si afisare lista de elemente maxime de pe linii\n4. Creare si afisare lista de elemente maxime de pe coloane\n5. Afisare matrice transpusa\n6. Adauga linie\n7. Adauga coloana\n8. Sterge linie\n9. Sterge coloana\n10. Liniarizare matrice (creare si afisare vector rezultat)")
        option = int(input("Optiunea: "))

        match option:

            case 1:
                one()

            case 2:
                print(mat)

            case 3:
                three()

            case 4:
                four()

            case 5:
                five()

            case 6:
                six()

            case 7:
                seven()

            case 8:
                eight()

            case 9:
                nine()

            case 10:
                ten()

menu()