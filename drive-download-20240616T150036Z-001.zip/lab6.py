def one():
    note = {}
    stud = {}
    N = int(input("Numar de studenti: "))
    print("id,Nume Prenume,nota_1 nota_2 ... nota_n")
    for i in range(N):
        info = input(f"Student {i+1}: ").split(",")
        id = info[0]
        stud[id] = info[1]
        note[id] = list(map(int, info[2].split()))
    return stud,note
def two(stud):
    print("ID\tNume")
    for i in stud:
        print(f"{i}\t{stud[i]}")

def three(note):
    print("ID\tNote")
    for i in note:
        print(f"{i}\t{note[i]}")

def four(stud,note):
    print("ID\tStudent\tNote")
    for i in stud:
        print(f"{i}\t{stud[i]}\t{note[i]}")

def five(stud,note):
    x = input("Nume studentului: ")
    found = 0
    for i in stud:
        if stud[i] == x:
            found = 1
            print("ID\tStudent\tNote")
            print(f"{i}\t{stud[i]}\t{note[i]}")
        if found==1:
            break
    if found==0:
        print(f"No student with name {x} was found. Check the spelling.")

def six(stud,note):
    prom = 0
    neprom = {1,2,3,4}
    for i in stud:
        if all(i not in neprom for i in note[i]):
            prom += 1
            print("ID\tStudent\tNote")
            print(f"{i}\t{stud[i]}\t{note[i]}")
    if prom == 0:
        print("Nu a promovat nimeni")
def menu():
    while 1:
        print("1. Incarcare informatii despre studenti de la tastatura\n2. Afisare studenti\n3. Afisare note\n4. Afisare studenti si notele obtinute\n5. Cautare student dupa nume\n6. Afisare studenti promovati\n7. Info autor\n8. Termina program")
        option = int(input("Optiunea: "))

        match option:
            case 1:
                stud, note = one()
            case 2:
                two(stud)
            case 3:
                three(note)
            case 4:
                four(stud,note)
            case 5:
                five(stud,note)
            case 6:
                six(stud,note)
menu()