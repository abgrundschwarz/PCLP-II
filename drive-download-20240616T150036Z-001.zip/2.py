def one():
    global den, mat, n, m
    den = input("Numiti matricea: ")
    n = int(input("Numar de linii: "))
    m = int(input("Numar de coloane: "))

    mat = [[0 for j in range(m)] for i in range(n)]
    for i in range(n):
        for j in range(m):
            mat[i][j] = int(input(f"Dati element [{i}][{j}]: "))
    print(mat)

def two():
    global mat
    for linie in mat:
        print(linie)

def three():
    global mat
    maxim = []
    for linie in mat:
        maxim.append(max(linie))
    print(maxim)

def four():
    max_col = [0]*m
    coloana = [0] * n
    for j in range(m):
        for i in range(n):
            coloana[i] = mat[i][j]
        max_col[j]=max(coloana)
    print(max_col)

def five():
    mat2 = [[0 for j in range(m)] for i in range(n)]

    for i in range(m):
        for j in range(n):
            mat2[j][i] = mat[i][j]

    for linie in mat2:
        print(linie)
def menu():
    while(True):

        print(f"1. Citire matrice de la tastatura (pe linii)\n2. Afisare matrice\n3. Creare si afisare lista de elemente maxime de pe linii\n4. Creare si afisare lista de elemente maxime de pe coloane\n5. Afisare matrice transpusa\n6. Adauga linie\n7. Adauga coloana\n8. Sterge linie\n9. Sterge coloana\n10. Liniarizare matrice (creare si afisare vector rezultat)\n 0. Exit")
        option = int(input("Alegeti optiunea: "))

        match option:

            case 1:
                one()

            case 2:
                two()

            case 3:
                three()

            case 4:
                four()

            case 5:
                five()

            case 0:
                break

menu()