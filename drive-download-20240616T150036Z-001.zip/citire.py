mat = []
with open("input.txt") as file:
    data = file.readlines()

    n = int(data[0])

    for i in range(1,n+1):
        mat.append(data[i].split())
    for i in range(n):
        print(mat[i])